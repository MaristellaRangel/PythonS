nome = input("Digite seu nome: ").upper()
fim = len(nome)
for i in range(len(nome)):
    print(nome[0:fim])
    fim = fim -1

