num_tel = input("Informe seu número de telefone: ")
num_tel= num_tel.replace('-','')

if len(num_tel) == 8:
    num_tel = '9' + num_tel
print(f"Número de telefone {num_tel}")