nome = input("Digite seu nome: ").upper()
nome = nome[::-1]
for letra in nome:
  print(letra)
