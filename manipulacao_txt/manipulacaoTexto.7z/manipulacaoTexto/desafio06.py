nome = input("Digite seu nome: ").upper()
fim = 1
for i in range(len(nome)):
    print(nome[0:fim])
    fim += 1
