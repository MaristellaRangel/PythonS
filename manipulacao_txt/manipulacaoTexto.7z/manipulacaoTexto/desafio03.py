cidade = input("Digite o nome da cidade: ").title() #primeira letra de cada palavra maiúscula
cidade_partes = cidade.split(' ')

if cidade_partes[0] == 'Santo':
    print("Começa com o nome Santo")
else:
    print("Não começa com o nome Santo")