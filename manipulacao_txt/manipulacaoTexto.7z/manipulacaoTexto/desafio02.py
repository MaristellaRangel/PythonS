num = input("Digite um número")
casas = ['Unidade', 'Dezena', 'Centena', 'Milhar']
digitos = []

if int(num) >= 1000 and int(num) <= 9999:
    for digito in num:
        digitos.append(digito)
    digitos.reverse()
    for i in range(4):
        print(f"{casas[i]} : {digitos[i]}")
else:
    print("Número inválido")
