nome = input("Digite seu nome: ")
print(f"Em maiúsculas: {nome.upper()}")
print(f"Em minúsculas: {nome.lower()}")
print(f"Quantidade de letras com espaço: {len(nome)}")

qtd_espacos = nome.count(" ")
print(f"Quantidade de letras sem espaço {len(nome) - qtd_espacos}")

nome_lista = nome.split(' ')
print(f"Quantidade de letras no primeiro nome {len(nome_lista[0])}")