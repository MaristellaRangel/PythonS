import math
import validacoes
import dicionarios

def converterBinDec(num):
    potencias = []
    decimal = 0
    if validacoes.validarBinario(num):
        for potencia in range(len(num)):
            potencias.append(math.pow(2, int(potencia)))
        potencias.reverse()

        for digito in range(len(num)):
            decimal += int(num[digito]) * potencias[digito]
        print(int(decimal))
    else:
        print("Valor inválido")


def converterBinHex(num):
   quarteto = ''
   inicio = 0
   fim = 4
   if validacoes.validarBinario(num):
       num2 = '0'
       while len(num) % 4 != 0:
           num = num2 + num

       divisoes = len(num) // 4
       for vez in range(divisoes):
           for n in range(inicio, fim):
               quarteto += num[n]
           inicio += 4
           fim += 4
           quarteto += '.'
       binario = quarteto.split('.')
       binario.pop(-1)

       hexadecimal = ' '
       for n in range(len(binario)):
           hexadecimal += dicionarios.dicBinHex[binario[n]]
       print(hexadecimal)
   else:
       print("Valor inválido")


def converterDecBin(num):
    restos = []
    resto = ''
    binario = ''

    if validacoes.validarDecimal(num):
        num = int(num)
        while num >= 2:
            resto = num % 2
            restos.append(str(resto))
            num = num // 2
        restos.reverse()
        binario = str(num)

        for indice in range(len(restos)):
            binario += restos[indice]
        print(binario)
    else:
        print("Valor inválido")


def converterDecHex(num):
    digitos_hexadecimal = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    restos = []
    resto = ''
    hexadecimal = ''

    if validacoes.validarDecimal(num):
        num = int(num)
        while num >= 16:
            resto = num % 16
            restos.append(resto)
            num = num // 16
        restos.reverse()
        hexadecimal = str(digitos_hexadecimal[num])

        for indice in range(len(restos)):
            hexadecimal += digitos_hexadecimal[restos[indice]]
        print(hexadecimal)
    else:
        print("Valor inválido")

def converterHexBin(num):
   if validacoes.validarHexadecimal(num):
       binario = ''
       for digito in num:
           binario += dicionarios.dicHexBin[digito]

       while (binario[0] == '0'):
           binario = binario.replace('0', '', 1)
       print(binario)
   else:
       print("Valor inválido")