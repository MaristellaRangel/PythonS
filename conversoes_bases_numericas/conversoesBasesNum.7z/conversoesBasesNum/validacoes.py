def validarHexadecimal(num):
    hexadecimal = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    for digito in num:
        if digito in hexadecimal:
            retorno = True
        else:
            retorno = False
            break
    return retorno

def validarDecimal(num):
    decimal = ['0', '1', '2', '3', '4', '5', '6', '7', '8','9']
    for digito in num:
        if digito in decimal:
            retorno = True
        else:
            retorno = False
            break
    return retorno


def validarBinario(binario):
    for digito in binario:
        if digito != '0' and digito != '1':
            retorno = False
            break
        else:
            retorno = True
    return retorno