import math
import validar_binario

def converter(num):
    potencias = []
    decimal = 0
    if validar_binario.validar_binario(num):
        for potencia in range(len(num)):
            potencias.append(math.pow(2, int(potencia)))
        potencias.reverse()

        for digito in range(len(num)):
            decimal += int(num[digito]) * potencias[digito]
        print(int(decimal))
    else:
        print("Valor inválido")
