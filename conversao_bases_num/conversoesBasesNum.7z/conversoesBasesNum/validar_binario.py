def validar_binario(binario):
    for digito in binario:
        if digito != '0' and digito != '1':
            retorno = False
            break
        else:
            retorno = True
    return retorno