import dic_bin_hex

def converter(num_bin):
   quarteto = ''
   inicio = 0
   fim = 4
   divisoes = len(num_bin) // 4
   for vez in range(divisoes):
       for n in range(inicio, fim):
           quarteto += num_bin[n]
       inicio += 4
       fim += 4
       quarteto += '.'
   binario = quarteto.split('.')
   binario.pop(-1)

   hexadecimal = ' '
   for n in range(len(binario)):
       hexadecimal += dic_bin_hex.conversao[binario[n]]
   print(hexadecimal)
