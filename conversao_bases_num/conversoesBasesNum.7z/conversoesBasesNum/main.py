import converter_bin_hex
import converter_dec_bin
import converter_hex_bin

print(""""
  ##### Escolha uma opção #####
  1 - converter de binário para hexadecimal
  2 - converter de hexadecimal para binário
  3 - converter de decimal para binário
  """)

res = 's'
while res == 's':
   opc = int(input("opção: "))
   if opc < 1 or opc > 3:
      print("Opção inválida")
   else:
      num = input("Número: ")
      if opc == 1:
         num2 = '0'
         while len(num) % 4 != 0:
            num = num2 + num
         converter_bin_hex.converter(num)
      elif opc == 2:
         num = num.upper()
         converter_hex_bin.converter(num)
      elif opc == 3:
         converter_dec_bin.converter(num)
   res = input("Deseja continuar? digite s ou n ").lower()
