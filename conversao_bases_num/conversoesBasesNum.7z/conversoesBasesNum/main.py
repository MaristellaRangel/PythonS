import converter_bin_hex
import converter_dec_bin
import converter_hex_bin
import converter_bin_dec
import converter_dec_hex

print(""""
  ##### Escolha uma opção #####
  1 - converter de binário para hexadecimal
  2 - converter de hexadecimal para binário
  3 - converter de decimal para binário
  4 - converter de binário para decimal
  5 - converter de decimal para hexadecimal
  """)

opcoes = ['1', '2', '3', '4','5']

res = 's'
while res == 's':
   opc = input("opção: ")
   if opc not in opcoes:
      print("Opção inválida")
   else:
      num = input("Número: ")
      if opc == '1':
         converter_bin_hex.converter(num)
      elif opc == '2':
         num = num.upper()
         converter_hex_bin.converter(num)
      elif opc == '3':
         converter_dec_bin.converter(num)
      elif opc == '4':
         converter_bin_dec.converter(num)
      elif opc == '5':
         converter_dec_hex.converter(num)


   res = input("Deseja continuar? digite s ou n ").lower()
