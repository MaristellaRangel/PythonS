import validar_decimal
def converter(num):
    digitos_hexadecimal = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F']
    restos = []
    resto = ''
    hexadecimal = ''

    if validar_decimal.validar_decimal(num):
        num = int(num)
        while num >= 16:
            resto = num % 16
            restos.append(resto)
            num = num // 16
        restos.reverse()
        hexadecimal = str(digitos_hexadecimal[num])

        for indice in range(len(restos)):
            hexadecimal += digitos_hexadecimal[restos[indice]]
        print(hexadecimal)
    else:
        print("Valor inválido")
