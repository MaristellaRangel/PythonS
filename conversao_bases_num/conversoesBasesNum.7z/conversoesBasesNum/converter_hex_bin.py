import dic_hex_bin
import validar_hexadecimal

def converter(num):
   if validar_hexadecimal.validar_hexadecimal(num):
       binario = ''
       for digito in num:
           binario += dic_hex_bin.conversao[digito]

       while (binario[0] == '0'):
           binario = binario.replace('0', '', 1)
       print(binario)
   else:
       print("Valor inválido")