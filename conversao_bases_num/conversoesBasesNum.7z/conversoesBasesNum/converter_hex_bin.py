import dic_hex_bin

def converter(num):
    binario = ''
    for digito in num:
        binario += dic_hex_bin.conversao[digito]

    while(binario[0] == '0'):
        binario = binario.replace('0','',1)
    print(binario)