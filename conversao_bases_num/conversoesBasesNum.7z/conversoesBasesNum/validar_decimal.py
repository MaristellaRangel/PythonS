def validar_decimal(num):
    decimal = ['0', '1', '2', '3', '4', '5', '6', '7', '8','9']
    for digito in num:
        if digito in decimal:
            retorno = True
        else:
            retorno = False
            break
    return retorno


