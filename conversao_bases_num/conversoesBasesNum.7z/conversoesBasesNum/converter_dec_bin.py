def converter(num):
    num = int(num)
    restos = []
    resto = ''
    binario = ''

    while num >= 2:
        resto = num % 2
        restos.append(str(resto))
        num = num // 2
    restos.reverse()
    binario = str(num)

    for indice in range(len(restos)):
        binario += restos[indice]
    print(binario)