import validar_decimal
def converter(num):
    restos = []
    resto = ''
    binario = ''

    if validar_decimal.validar_decimal(num):
        num = int(num)
        while num >= 2:
            resto = num % 2
            restos.append(str(resto))
            num = num // 2
        restos.reverse()
        binario = str(num)

        for indice in range(len(restos)):
            binario += restos[indice]
        print(binario)
    else:
        print("Valor inválido")
