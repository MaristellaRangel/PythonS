from netflix import Cliente as C
clientes = []

def menu():
    while True:
        print('[0] - Sair\n[1] - Cadastrar\n[2] - Entrar\n[3] - Registrar Filme\n[4] - Listar Filmes')
        opcao = input("Escolha uma opção: ")
        if opcao.isdigit():
            opcao = int(opcao)
            if opcao < 0 or opcao > 4:
                print("Opção inválidada")
            else:
                if opcao == 0:
                    break
                if opcao == 1:
                    nome = input("Nome: ")
                    email = input("Email: ")
                    print("Planos: | basic | medium | premium")
                    while True:
                        plano = input("Plano: ")
                        if plano in C.planos:
                            break
                        else:
                            print("Plano inválido")

                    while True:
                        tipo = input("Tipo: ")
                        if tipo in C.tipos:
                            break
                        else:
                            print("Tipo inválido")

                    if not C.verificarCadastro(clientes, email):
                        cliente = C(nome, email, plano, tipo)
                        clientes.append(cliente)
                        print("Cadastrou")
                    else:
                        print("Cliente já cadastrado")
                if opcao == 2:
                    email_cliente = input("Email: ")
                    if C.verificarEmail(clientes, email_cliente):
                        print("Entre")
                    else:
                        print("Este email não está cadastrado!")
                if opcao == 3:
                    email_cadastrar_filme = input("Email: ")
                    if C.verificarEmail(clientes, email_cadastrar_filme):
                       cliente =  C.pegarCliente(lista=clientes, emailc=email_cadastrar_filme)
                       tipo_cliente = C.pegarTipo(cliente)
                       if tipo_cliente == 'admin':
                           while True:
                              categoria = input("Categoria: ")
                              while categoria not in C.planos:
                                  print("Categoria inválida")
                                  categoria = input("Categoria: ")
                              filme = input('Filme: ')
                              indice_filmes = C.pegarIndiceFilmes(categoria)
                              if filme not in C.filmes:
                                  C.filmes[indice_filmes].append(filme)
                                  resp = input("Deseja continuar? [S] ").upper()
                              if resp != "S":
                                  break
                       else:
                           print("Você não é adm")
                    else:
                        print("Apenas adms cadastrados podem registrar filmes!")
                if opcao == 4:
                    print(f"Filmes plano basic: {C.filmes[0]}")
                    print(f"Filmes plano medium: {C.filmes[1]}")
                    print(f"Filmes plano premium: {C.filmes[2]}")
        else:
            print("Por favor, digite um número")

menu()
