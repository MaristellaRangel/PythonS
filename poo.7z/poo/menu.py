from netflix import Cliente

cadastro = []
clientes = []
filmes = [[], [], []]
#novo_usuario = []

def verificarCadastro(clientes, email):
    esta_cadastrado = False
    for c in clientes:
        if c.email != email:
            esta_cadastrado = False
        else:
            esta_cadastrado = True
            break
        return esta_cadastrado

def verificarEmail(clientes, email):
    email_esta_cadastrado = False
    for c in clientes:
        if c.email == email:
            email_esta_cadastrado = True
            break
        else:
            email_esta_cadastrado = False
    return email_esta_cadastrado

def pegarPlano(clientes, email):
    for c in clientes:
        if c.email == email:
            plano = c.plano
            break
    return plano

def pegarIndiceFilmes(plano):
    if plano == 'basic':
        indice_filmes = 0
    elif plano == 'medium':
        indice_filmes = 1
    elif plano == 'premium':
        indice_filmes = 2
    return indice_filmes

def menu():
    while True:
        print('[0] - Sair\n[1] - Cadastrar\n[2] - Entrar\n[3] - Registrar Filme\n[4] - Listar Filmes')
        opcao = input("Escolha uma opção: ")
        if opcao.isdigit():
            opcao = int(opcao)
            if opcao < 0 or opcao > 4:
                print("Opção inválidada")
            else:
                if opcao == 0:
                    break
                if opcao == 1:
                    nome = input("Nome: ")
                    email = input("Email: ")
                    print("Planos: | basic | medium | premium")
                    while True:
                        plano = input("Plano: ")
                        if plano in Cliente.planos:
                            break
                        else:
                            print("Plano inválido")

                    if not verificarCadastro(clientes, email):
                        cliente = Cliente(nome, email, plano)
                        clientes.append(cliente)
                    else:
                        print("Cliente já cadastrado")
                if opcao == 2:
                    email_cliente = input("Email: ")
                    if verificarEmail(clientes, email_cliente):
                        print("Entre")
                    else:
                        print("Este email não está cadastrado!")
                if opcao == 3:
                    indice_filmes = 0
                    email_cadastrar_filme = input("Email: ")
                    if verificarEmail(clientes, email_cadastrar_filme):
                        plano_registrar_filme = pegarPlano(clientes, email_cadastrar_filme)
                        indice_filmes = pegarIndiceFilmes(plano_registrar_filme)
                        while True:
                            filme = input("Filme: ")
                            if filme not in filmes:
                                filmes[indice_filmes].append(filme)
                            resp = input("Deseja continuar? [S]").upper()
                            if resp != "S":
                                print(filmes)
                                break
                    else:
                        print("Apenas pessoas cadastradas podem registrar filmes!")
                if opcao == 4:
                    print(f"Filmes plano basic: {filmes[0]}")
                    print(f"Filmes plano medium: {filmes[1]}")
                    print(f"Filmes plano premium: {filmes[2]}")
        else:
            print("Por favor, digite um número")

menu()
