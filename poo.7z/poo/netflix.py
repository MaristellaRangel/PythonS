class Cliente:
    planos = ['basic', 'medium', 'premium']
    filmes = [[], [], []]
    tipos = ['admin', 'user']

    def verificar_plano(self, plano):
        if plano in Cliente.planos:
            self.plano = plano
        else:
            self.plano = "inválido"

    def verificar_tipo(self, tipo):
        if tipo in Cliente.tipos:
            self.tipo = tipo
        else:
            self.tipo = "inválido"

    def __init__(self, nome:str, email:str, plano:str, tipo:str):
        self.nome = nome
        self.email = email
        self.plano = plano
        self.verificar_plano(self.plano)
        self.tipo = tipo
        self.verificar_tipo(self.tipo)

    def pegarPlano(self):
        return self.plano

    def pegarTipo(self):
        return self.tipo

    @classmethod
    def pegarCliente(cls, lista, emailc):
       for c in lista:
           if c.email == emailc:
                return c

    def mudar_plano(self, plano):
        self.verificar_plano(plano)

    def verFilme(self, filme, plano_filme):
        if self.plano ==  "premium" or self.plano == plano_filme or (self.plano == 'medium' and plano_filme == 'basic'):
            print(f"O cliente {self.nome} PODE assistir o filme {filme}")
        else:
            print(f"O cliente {self.nome} NÃO PODE assistir o filme {filme}")

    @classmethod
    def adicionar_planos(cls, lista, plano):
        lista.append(plano)
        print(lista)

    @classmethod
    def verificarCadastro(cls, clientes, e):
        esta_cadastrado = False
        for c in clientes:
            if c.email != e:
                esta_cadastrado = False
            else:
                esta_cadastrado = True
                break
        return esta_cadastrado

    @classmethod
    def verificarEmail(cls, clientes, email):
        email_esta_cadastrado = False
        for c in clientes:
            if c.email == email:
                email_esta_cadastrado = True
                break
            else:
                email_esta_cadastrado = False
        return email_esta_cadastrado

    @classmethod
    def pegarIndiceFilmes(cls, plano):
        if plano == 'basic':
            indice_filmes = 0
        elif plano == 'medium':
            indice_filmes = 1
        elif plano == 'premium':
            indice_filmes = 2
        return indice_filmes



