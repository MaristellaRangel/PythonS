class Cliente:
    planos = ['basic', 'medium', 'premium']
    filmes = [[], [], []]

    def verificar_plano(self, plano):
        if plano in Cliente.planos:
            self.plano = plano
        else:
            self.plano = "inválido"

    def __init__(self, nome:str, email:str, plano:str):
        self.nome = nome
        self.email = email
        self.plano = plano
        self.verificar_plano(self.plano)


    def mudar_plano(self, plano):
        self.verificar_plano(plano)

    def verFilme(self, filme, plano_filme):
        if self.plano ==  "premium" or self.plano == plano_filme or (self.plano == 'medium' and plano_filme == 'basic'):
            print(f"O cliente {self.nome} PODE assistir o filme {filme}")
        else:
            print(f"O cliente {self.nome} NÃO PODE assistir o filme {filme}")

    @classmethod
    def adicionar_planos(cls, lista, plano):
        lista.append(plano)
        print(lista)
