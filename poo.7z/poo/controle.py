class ControleRemoto:
    def __init__(self, valorCor:str, a:float, p:float, l:float):
        self.cor = valorCor
        self.altuta = a
        self.profundidade = p
        self.largura = l

    def passar_canal(self, botao):
        if botao == "+":
            print("Próximo Canal")
        elif botao == "-":
            print("Canal anterior")