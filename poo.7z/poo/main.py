from controle import ControleRemoto
from netflix import Cliente

controle1 = ControleRemoto("Azul", 3, 2, 1)
controle1.passar_canal("+")

cliente1 = Cliente("Daniele", "dani@gmail.com", "medium")
print(cliente1.nome)
print(f"Plano atual: {cliente1.plano}")

# Cliente.adicionar_planos(Cliente.planos, "diamante")

# cliente1.mudar_plano("premium")
# print(f"Plano novo: {cliente1.plano}")
cliente1.verFilme("Home Aranha", "basic")