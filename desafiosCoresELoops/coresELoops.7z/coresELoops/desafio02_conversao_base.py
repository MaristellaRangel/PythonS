import desafio02_funcoes
while True:
    print("""
    Escolha uma das bases para a conversão:
    [0] Sair
    [1] Binário
    [2] Octal
    [3] Hexadecimal
    """)
    opcao = input("Opção: ")
    if opcao == '0':
        break
    numero = input("Digite um número: ")

    if opcao == '1':
        desafio02_funcoes.converterParaBin(numero)
    elif opcao == '2':
        desafio02_funcoes.converterParaOctal(numero)
    elif opcao == '3':
        desafio02_funcoes.converterParaHexadecimal(numero)
    else:
        print("Opção inválida")