def converterParaBin(n):
    restos = []
    resto = ""
    binario = ""

    if n.isdigit():
        n = int(n)
        while n >= 2:
            resto = n % 2
            restos.append(str(resto))
            n = n // 2
        restos.reverse()

        binario = str(n)  # ultimo quociente

        for r in restos:
            binario += r
        print(binario)
    else:
        print("Valor inválido")

def converterParaOctal(n):
    restos = []
    resto = ""
    octal = ""

    if n.isdigit():
        n = int(n)
        while n >= 8:
            resto = n % 8
            restos.append(str(resto))
            n = n // 8
        restos.reverse()

        octal = str(n)  # ultimo quociente

        for r in restos:
            octal += r
        print(octal)
    else:
        print("Valor inválido")

def converterParaHexadecimal(n):
    digitosHex = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F"]
    restos = []
    resto = ""
    hex = ""

    if n.isdigit():
        n = int(n)
        while n >= 16:
            resto = n % 16
            restos.append(resto)
            n = n // 16
        restos.reverse()
        hex = str(digitosHex[n])  # ultimo quociente

        for r in restos:
            hex += digitosHex[r]
        print(hex)
    else:
        print("Valor inválido")
